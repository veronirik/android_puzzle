package com.example.k15puzzle

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegistActivity : AppCompatActivity() {

	private lateinit var newUsernameEditText: EditText
	private lateinit var newPasswordEditText: EditText
	private lateinit var errorTextView: TextView
	private lateinit var dbHelper: DatabaseHelper
	private lateinit var backButton: Button

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_regist)

		newUsernameEditText = findViewById(R.id.newUsernameEditText)
		newPasswordEditText = findViewById(R.id.newPasswordEditText)
		errorTextView = findViewById(R.id.errorTextView)
		val confirmButton: Button = findViewById(R.id.confirmButton)
		backButton = findViewById(R.id.backButton)

		dbHelper = DatabaseHelper(this)

		confirmButton.setOnClickListener {
			val username = newUsernameEditText.text.toString().trim()
			val password = newPasswordEditText.text.toString().trim()

			when {
				username.isEmpty() || password.isEmpty() -> {
					showError("Все поля должны быть заполнены")
				}
				!isValidInput(username) || !isValidInput(password) -> {
					showError("Логин и пароль должны содержать только английские буквы и цифры")
				}
				else -> {
					// Хэшируем пароль перед записью в БД
					val hashedPassword = HashingPassword.hashPassword(password)

					if (dbHelper.addUser(username, hashedPassword)) {
						Toast.makeText(this, "Регистрация успешна", Toast.LENGTH_SHORT).show()
						startActivity(Intent(this, Activity15Puzzle::class.java))
						finish()
					} else {
						showError("Пользователь уже существует")
					}
				}
			}
		}

		// Обработчик для кнопки "Вернуться назад"
		backButton.setOnClickListener {
			startActivity(Intent(this, StartActivity::class.java))
			finish()
		}
	}

	private fun isValidInput(input: String): Boolean {
		return input.matches(Regex("^[a-zA-Z0-9]+$"))
	}

	private fun showError(message: String) {
		errorTextView.text = message
		errorTextView.visibility = View.VISIBLE
	}
}