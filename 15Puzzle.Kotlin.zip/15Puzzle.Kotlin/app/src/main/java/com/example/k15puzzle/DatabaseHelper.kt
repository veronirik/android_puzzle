package com.example.k15puzzle

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

	companion object {
		private const val DATABASE_NAME = "users.db"
		private const val DATABASE_VERSION = 1

		const val TABLE_USERS = "users"
		const val COLUMN_USERNAME = "username"
		const val COLUMN_PASSWORD = "password"
	}

	override fun onCreate(db: SQLiteDatabase) {
		val createTable = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_USERNAME TEXT PRIMARY KEY,
                $COLUMN_PASSWORD TEXT
            )
        """.trimIndent()
		db.execSQL(createTable)
	}

	override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
		db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
		onCreate(db)
	}

	fun addUser(username: String, hashedPassword: String): Boolean {
		val db = writableDatabase
		val values = ContentValues().apply {
			put(COLUMN_USERNAME, username)
			put(COLUMN_PASSWORD, hashedPassword) // Сохраняем уже хэшированный пароль
		}

		val result = db.insert(TABLE_USERS, null, values)
		return result != -1L
	}

	fun checkUser(username: String, hashedPassword: String): Boolean {
		val db = readableDatabase
		var cursor: Cursor? = null
		return try {
			val query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?"
			cursor = db.rawQuery(query, arrayOf(username, hashedPassword))
			cursor.moveToFirst()
		} finally {
			cursor?.close()
		}
	}
}