package com.example.k15puzzle

import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.nio.charset.StandardCharsets
import java.math.BigInteger

object HashingPassword {

	fun hashPassword(password: String): String {
		return try {
			val digest = MessageDigest.getInstance("SHA-256")
			val hash = digest.digest(password.toByteArray(StandardCharsets.UTF_8))

			// Конвертируем хэш в строку HEX
			val number = BigInteger(1, hash)
			val hexString = StringBuilder(number.toString(16))

			// Дополняем нулями до длины 64 символа
			while (hexString.length < 64) {
				hexString.insert(0, '0')
			}

			hexString.toString()
		} catch (e: NoSuchAlgorithmException) {
			throw RuntimeException("Ошибка хэширования пароля", e)
		}
	}
}