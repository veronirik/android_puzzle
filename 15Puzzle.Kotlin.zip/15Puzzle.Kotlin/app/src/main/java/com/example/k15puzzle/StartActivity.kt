package com.example.k15puzzle

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class StartActivity : AppCompatActivity() {

	private lateinit var usernameEditText: EditText
	private lateinit var passwordEditText: EditText
	private lateinit var registerButton: Button
	private lateinit var enterButton: Button
	private lateinit var dbHelper: DatabaseHelper

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_start)

		// Инициализация элементов
		usernameEditText = findViewById(R.id.usernameEditText)
		passwordEditText = findViewById(R.id.passwordEditText)
		registerButton = findViewById(R.id.registerButton)
		enterButton = findViewById(R.id.enterButton)

		dbHelper = DatabaseHelper(this)

		// Обработчик клика по кнопке "Войти"
		enterButton.setOnClickListener {
			val username = usernameEditText.text.toString().trim()
			val password = passwordEditText.text.toString().trim()

			// Хэшируем введенный пароль перед проверкой
			val hashedPassword = HashingPassword.hashPassword(password)

			if (dbHelper.checkUser(username, hashedPassword)) {
				Toast.makeText(this, "Добро пожаловать!", Toast.LENGTH_SHORT).show()
				startActivity(Intent(this, Activity15Puzzle::class.java))
				finish()
			} else {
				Toast.makeText(this, "Неверный логин или пароль!", Toast.LENGTH_SHORT).show()
			}
		}

		// Обработчик клика по кнопке "Регистрация"
		registerButton.setOnClickListener {
			val intent = Intent(this, RegistActivity::class.java)
			startActivity(intent)
			finish()
		}
	}
}